import React from "react";
import { Col, Form, Container, FormGroup, Input, Row } from "reactstrap";
import CommonSection from '../comman_section/common_section.jsx';
import "../contact_page/contact_page.css";
const Contact = ({ contactusClass }) => {
  return (
    <>
      
      <section
        className="about__section"
        style={
          contactusClass === "aboutPage"
            ? { marginTop: "0px" }
            : { marginTop: "58.5px" }
        }
      />
      <CommonSection title="Contact Us" />
      <section style={{height:'85vh'}} className=''>
        
        <Container>
          
          <Row>
            
            <Col lg="7" md="7">
              
              <h5 className="fw-bold mb-4">Get In Touch </h5>
              <Form>
                
                <FormGroup className="contact__form">
                  
                  <Input placeholder="Your Name" type="text" />
                </FormGroup>
                <FormGroup className="contact__form">
                  
                  <Input placeholder="SAP ID" type="number" />
                </FormGroup>
                <FormGroup className="contact__form">
                  
                  <Input placeholder="Email" type="email" />
                </FormGroup>
                <FormGroup className="form-outline mb-4">
                  
                  <textarea
                    placeholder="Message"
                    className="form-control"
                    id="textAreaExample6"
                    rows="3"
                  />
                </FormGroup>
                <button className="contact_btn" type="submit" style={{backgroundColor:'rgb(95 30 190)'}}>
                  
                  Send Query
                </button>
                <button className="contact_btn" type="reset" style={{backgroundColor:'rgb(95 30 190)'}}>
                  
                  Clear
                </button>
              </Form>
            </Col>
            <Col lg="5" md="5">
              
              <div className="adminmsg">
                
                <h4 className="fw-bold">Admins Message!</h4>
                <p className="section__description mb-0">
                  
                  Your Query will be responded ASAP, please wait patiently
                </p>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};
export default Contact;
