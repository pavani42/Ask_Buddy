const Main=(p)=>{
    return (

        <>
        <div className="detailed-div-5-ans-bar">
          <hr/>
          <h4 style={{color:'black'}}>Answer</h4>
          {p.Answer}
        </div>
        </>
    );
}

export default Main;