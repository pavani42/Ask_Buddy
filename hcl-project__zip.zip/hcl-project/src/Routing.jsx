import { Routes,Route} from "react-router-dom";
import Login from './login/login.jsx';
import Registration from './Signup/sign_up_page.jsx';
import Collected_1 from './collected_ques_ans_page.jsx';
import Collected_2 from './collected_homepage_content.jsx';
import FAQ from './FAQ_page/faq.jsx'
import Nav from './main_content/nav.jsx';
import Footer from './main_content/footer.jsx'
import AboutUs from './Aboutus_page/aboutus_main.jsx';
import ContactUs from './contact_page/contact_page.jsx'
import JoinUs from './joinus_page/joinus_page.jsx';
import IndividualQuesAnsPage from './Detailed_ques_ans_page/detailed_ques_ans_page.jsx';
import { dividerClasses } from "@mui/material";
const Main=()=>{
  return( 

    <>
    {/* <h1>HIHI</h1> */}
    {/* <Nav/> */}
    <Routes>
        <Route path='/' element={<Collected_2/>}></Route>
        <Route path='/ques-ans-page' element={<><Collected_1/></>}></Route>
        <Route path='/ques-ans-page/:slug' element={<><Nav/><div className='' style={{width:'100%',display:'flex',justifyContent:'center'}}><div className="window-width-resp"><IndividualQuesAnsPage/></div></div><Footer/></>}></Route>
        <Route path='/faq' element={<><Nav/><div className='' style={{width:'100%',display:'flex',justifyContent:'center'}}><div className="window-width-resp"><FAQ/></div></div><Footer/></>}></Route>
        <Route path='/login' element={<Login/>}></Route>
        <Route path='/registration' element={<Registration/>}></Route>
        {/* <Route path='/about-us' element={<><Nav/><div className='' style={{width:'100%',display:'flex',justifyContent:'center'}}><div className="window-width-resp"><AboutUs/></div></div><Footer/></>}></Route> */}
        <Route path='/contact-us' element={<><Nav/><div className='' style={{width:'100%',display:'flex',justifyContent:'center'}}><div className="window-width-resp"><ContactUs/></div></div><Footer/></>}></Route>
        <Route path='/join-us' element={<><Nav/><div className='' style={{width:'100%',display:'flex',justifyContent:'center'}}><div className="window-width-resp"><JoinUs/></div></div><Footer/></>}></Route>
        
    </Routes>
    {/* <Footer/> */}
    </>
  );
}
export default Main;