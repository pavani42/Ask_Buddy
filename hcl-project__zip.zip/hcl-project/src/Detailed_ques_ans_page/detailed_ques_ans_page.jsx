import {useParams} from 'react-router-dom';
import {useEffect} from 'react';
import data from '../Dummy_data/data.jsx';
import AnswerCard from '../Answer_component/answer.jsx';
import { color } from '@mui/system';
// import FontAwesomeIcon from ''
const Main=()=>{


    const {slug}=useParams();
    const a = data.find((item)=>item.Ques===slug);
    // console.log(a);
    useEffect(()=>{
        
    },[a]);
    return (

        
      
        <>
          <div className="detailed-div-1" style={{width:'100%',display:'flex',justifyContent:'center',marginTop:'80px'}}>
            <div className="detailed-div-2" style={{}}>
              <div className="detailed-div-3">
              <div className="detailed-div-3-content" style={{display:'flex'}}>
                <div className="detailed-div-5-like-dislike" style={{marginRight:'25px'}}>
                {/* <FontAwesomeIcon icon="fa-solid fa-triangle" /> */}
                  <p style={{fontSize:'35px',margin:'0',color:'grey'}}>&#9650;</p>
                  <p style={{fontSize:'25px',margin:'0'}}>10</p>
                  <p style={{fontSize:'35px',margin:'0',color:'grey'}}>&#9660; </p>
                </div>
                <div className="detailed-div-4-ques-bar">

                  <h2 style={{color:'black'}}>{a.Ques}</h2>
                  <hr/>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis alias animi voluptatem similique aspernatur voluptatum unde, minima laborum, perferendis, tenetur vitae reprehenderit esse aperiam rerum dolor rem commodi ipsa temporibus!
                  Voluptatibus nihil corrupti nemo dicta aspernatur quidem architecto cumque maiores perferendis, quae excepturi officiis ea vero consectetur aperiam quisquam molestias iste qui reiciendis ullam tempora, ipsa natus. Consectetur, accusamus architecto?
                  Dolores tempora odit, possimus rerum voluptatum repellat aliquid omnis quia fugiat quas voluptas, voluptate repudiandae! Esse nostrum ea commodi laboriosam sit voluptates architecto expedita. Cupiditate consectetur dolor voluptatum nobis molestias.
                  Temporibus odio aut minima voluptate illum facere hic excepturi dolor repellendus. Facere atque asperiores tempora quam laboriosam maiores dolorum aliquam, velit similique qui ab? Doloremque nulla sapiente accusantium nisi quo.
                </div>
              </div>
              <div className="detailed-div-6-like-dislike" style={{display:'flex'}}>
                <div className="detailed-div-5-like-dislike" style={{marginRight:'25px'}}>
                {/* <FontAwesomeIcon icon="fa-solid fa-triangle" /> */}
                  <p style={{fontSize:'35px',margin:'0',color:'grey'}}>&#9650;</p>
                  <p style={{fontSize:'25px',margin:'0'}}>10</p>
                  <p style={{fontSize:'35px',margin:'0',color:'grey'}}>&#9660; </p>
                </div>
                <AnswerCard Answer={a.Ans}/>
              </div>
              
              </div>

            </div>
 
          </div>
        </>
    );
}

export default Main;