const data=[
    {
      Ques:'What is the equivalent of this.state with the new react useState hook',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },
    {
      Ques:'How to install python 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, Lorem ipsum dolor, sit amet consectetur adipisicing elit. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis aliquid numquam reprehenderit in reiciendis architecto omnis Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
      Ques:'How to install php 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
      Ques:'How to install ruby 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
     Ques:'How to install Jasmine 88',
     Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Java 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },
]
export default data;