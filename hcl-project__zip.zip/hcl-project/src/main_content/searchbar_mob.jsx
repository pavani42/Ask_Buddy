import Data from '../Dummy_data/data.jsx'
import { useState } from 'react';
import { Link } from 'react-router-dom';
const Main = () => {
  const [val , setVal] = useState('');
  const submitSearch=(que)=>{
    console.log(que);
  }

  const onPuttingInput=(p)=>{
    // console.log(p.target.value);
    setVal(p.target.value);
  }
    return (
      <>
      <div class="dropdown-search show" >

        <form
          className="searchbox-main-4"
          id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"

          onSubmit={()=>submitSearch(val)}
          style={{
            
            marginLeft:"10px",
            marginRight:"10px",
            marginTop:"58.5px"
          }}
        >
          <div className="searchbox-main-5" style={{ display: "flex", height: "100%" }}>
            <input
            onChange={onPuttingInput}
              type="text"
              className="fa"
              placeholder="  Search questions here..."
              style={{ border: "none",margin: "15px 0px 6px 0px", width: "100%", height: "50px",borderRadius:"6px",paddingLeft:"10px",fontFamily:"'Helvetica', 'Arial', sans-serif"}}
            />
          </div>
        </form>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink" style={{width:'95%'}}>
            
            {Data.filter((item)=>{
              const searchTerm = val.toLowerCase();
              const fullQues = item.Ques.toLowerCase();
              return searchTerm && fullQues.startsWith(searchTerm);

            }).slice(0,5).map((item)=>(
              <Link class="dropdown-item" to={`/ques-ans-page/${item.Ques}`}>{item.Ques}</Link>
            ))}
          </div>
      </div>
        {/* <h1>HI</h1> */}
      </>
    );
  };
  export default Main;