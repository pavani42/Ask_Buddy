import Home from '../Aboutus_page/aboutus_main.jsx';

const Main=()=>{
    return (
        <>

        {/* <h1 style={{height:'81.5vh',marginTop:'58.5px'}}>HOMEEE</h1> */}
        <Home/>
        </>
    );
}

export default Main;