package com.hcl.ask_buddy.test.service;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.hcl.ask_buddy.dto.Answers;
import com.hcl.ask_buddy.repository.AnswerRepo;
import com.hcl.ask_buddy.service.AnswerService;

@SpringBootTest
public class TestAnswerService {
	
	
	

}
