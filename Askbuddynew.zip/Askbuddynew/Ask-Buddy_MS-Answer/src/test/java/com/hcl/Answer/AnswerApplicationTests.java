package com.hcl.Answer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnswerApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
