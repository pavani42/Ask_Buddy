const Main=(p)=>{
  console.log(p)
    return (
      
        <>
        <div className="detailed-div-5-ans-bar">
          
          {/* <h4 style={{color:'black'}}>Answer</h4> */}
          {p.Answer}
        </div>
        </>
    );
}

export default Main;