const data=[
    {
      Ques:'jhsfb',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },
    {
      Ques:'How to install python 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, Lorem ipsum dolor, sit amet consectetur adipisicing elit. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis aliquid numquam reprehenderit in reiciendis architecto omnis Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
      Ques:'How to install php 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
      Ques:'How to install ruby 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
     Ques:'How to install Jasmine 88',
     Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
    },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Jasmine 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },{
      Ques:'How to install Java 88',
      Ans:'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Natus enim praesentium, aliquid numquam reprehenderit in reiciendis architecto omnis',
     },
]
export default data;
// import React, { useState, useEffect } from 'react';
// import SendData1 from '../Detailed_ques_ans_page/detailed_ques_ans_page.jsx';
// import SendData2 from '../main_content/ques_ans_pg.jsx'
// import axios from 'axios';
// const MyComponent = () => {
//   const [data, setData] = useState([]);
//   useEffect(() => {
//     axios.get('http://localhost:9090/latestQuestion')
//       .then(response => {
//         const dataArray = response.data.results;
//         console.log(response.data.results);
//         setData(dataArray);
//       })
//       .catch(error => {
//         console.log(error);
//       });
//   }, []);
//   console.log(data);
//   // Pass the data array as a prop to the DisplayData component  
//   return (
//     <div><SendData1 data={data} /><SendData2 data={data} /></div>);
// }
// export default MyComponent;
