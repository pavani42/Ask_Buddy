import axios from 'axios';
import { useState } from 'react';
// import NavDropdown from "react-bootstrap/NavDropdown";
// import data from '../Dummy_data/data.jsx';
import Card from '../Ques_ans_card/Card.jsx';
import React, { useEffect , useContext} from "react";
import fetchData from '../FetchingDataFromApi/context.jsx'

const Main = () => {
  const [formData, setFormData] = useState({});
  const [closeModal, setCloseModal] = useState('');
  const [selectedOption, setSelectedOption] = useState('');
  // const [data,setData]=useState([]);
  const data = useContext(fetchData);
  const selectChange = (e) => {
    setSelectedOption(e.target.value);
    setFormData({ ...formData, Category: e.target.value });
  }
//   const fetchAPI=()=>{axios("http://localhost:9090/latestQuestion", {
//     method: "get",
//     headers: {
//       "Access-Control-Allow-Origin": "*",
//       "Content-Type": "application/json",
//       mode: "no-cors",
//     },

//   }).then((res) => {
//     setData(res.data);
//     console.log(res.data);
//   });
// };
// useEffect(fetchAPI ,[]);

console.log(data);
const submitHandle = async (event) => {
  event.preventDefault();
  if(localStorage.getItem('token') == null)
  {
    window.alert("Please login to post the question!");
    // window.location.href = '/login';
  }
  // else 
  const user = JSON.parse(localStorage.getItem('token'));
  console.log('Bearer ' + user);
  const response = await axios("http://localhost:9090/addQuestion?category=" + formData.Category + "&question= " + formData.Question + "&questionDescription=" + formData.Detailed_Question + "&sub_Category=java", {
        method: "post",
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Content-Type": "application/json",
          "Authorization": "Bearer " + user,
          mode: "no-cors",
        },
       
      });
  console.log(response);
  if (response.status == 200) {
    setTimeout(function () {
      document.getElementById("modalCloseButton").click();
      alert(response.data)
    }, 300);
  }
  else if(response.status == 400)
  {
    setTimeout(function () {
      document.getElementById("modalCloseButton").click();
      alert("Please Login");
    }, 300);
  }
}


return (
  <>
    {/* <h1 style={{height:"700px"}}>body</h1> */}

    {/* ////////////////////////////////////////////////////////////modal//////////////////////////////////////////////////////////////// */}
    <form onSubmit={submitHandle}>
      <div className="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div className="modal-dialog" role="document">
          <div className="modal-content">
            <div className="modal-header" style={{ backgroundColor: 'rgb(95 30 190)' }}>
              <h5 className="modal-title" id="exampleModalLabel" style={{ color: 'white' }}>Ask a question</h5>
              <button type="button" className="close" data-dismiss="modal" aria-label="Close" style={{ border: 'none', fontSize: '25px', backgroundColor: 'rgb(95 30 190)', color: 'white' }}>
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body">
              {/* <form> */}
              {/* <div className="dropdown" style={{marginBottom:'15px'}}> */}
              <select required value={selectedOption} style={{ color: 'rgb(95 30 190)' }} className="btn btn-secondary dropdown-toggle" onChange={selectChange} type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <option className="dropdown-item" value="">---Select Category---</option>
                <option className="dropdown-item" value="language">Language</option>
                <option className="dropdown-item" value="framework">Framework</option>
                <option className="dropdown-item" value="Technology">Technology</option>
                <option className="dropdown-item" value="other">Other</option>
              </select>
              {/* </div>                 */}
              <div className="form-group">
                <label for="question-asked" className="col-form-label" style={{ color: 'black' }}>Title</label>
                <input required type="text" className="form-control" id="question-asked" name='question' onChange={(e) => setFormData({ ...formData, Question: e.target.value })} />
              </div>
              <div className="form-group">
                <label for="message-text" className="col-form-label" style={{ color: 'black' }}>Details of question</label>
                <textarea required type="text" className="form-control" id="message-text" name="detailed-question" onChange={(e) => setFormData({ ...formData, Detailed_Question: e.target.value })}> </textarea>
              </div>
              {/* </form> */}
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" id="modalCloseButton" data-dismiss="modal">Close</button>
              <button type="submit" className="btn btn-primary" style={{ backgroundColor: 'rgb(95, 30, 190)' }}>ASK</button>
            </div>
          </div>
        </div>
      </div>
    </form>
    {/* ////////////////////////////////////////////////////////////modal//////////////////////////////////////////////////////////////// */}

    <div className="body-main-content" style={{ width: '100%', display: 'flex', justifyContent: 'center', marginBottom: '20px' }}>
      <div className="ques-ans-page-2" style={{ backgroundColor: 'white' }}>
        <div className="list-group w-100" >
          <div className="body-main-2" style={{ display: "flex", justifyContent: "space-between", margin: '0 10px 0 10px' }}>
            <h1 style={{ margin: "40px 10px 20px 0px", color: 'black' }}>Top Questions</h1>

            <a class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" className="" href="#" style={{ backgroundColor: "rgb(60 145 255)", width: "120px", padding: "17px 10px 10px 10px", color: "white", height: "60px", margin: "auto 10px auto 0", borderRadius: "5px", textDecoration: "none" }}>Ask Question</a>

          </div>

        </div>
        <div className="ques-ans-content-1">
          {data.map((val) => {
            return (
              <Card
                A={val.question.question}
                B={val.answerList.description}
              />
            );
          })}
        </div>
      </div>
    </div>
  </>
);
  };
export default Main;
